DUSK BOT ARCHIVE

This archive contains the latest bot source code and media assets.

Included features:
- Group chat replies
- Developer-only events
- /بحث [character] image search
- /Attack storm command with a 22-second interval
- Automatic session-state cookie persistence and reconnect handling

Security note:
The Facebook session cookies are intentionally not included.
Before running the bot, provide a fresh cookies.json through the secure workspace/API flow.
Never publish or share cookies.json.
